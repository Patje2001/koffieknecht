module BeveragesHelper
end
