class OrdersController < ApplicationController

    def new
        
    end
end
