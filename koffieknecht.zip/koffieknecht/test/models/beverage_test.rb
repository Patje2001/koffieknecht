require "test_helper"

class BeverageTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
